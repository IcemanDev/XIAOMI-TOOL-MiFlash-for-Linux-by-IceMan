
ITALIANO
1- Riavviare il dispositivo in modalità fastboot;
2- Connettere il dispositivo al pc tramite cavo usb;
3- Avviare il programma "XIAOMI TOOL" da terminale (cd Xiaomi_MiFlash && sudo ./go.sh) e copiare il file 
   del firmware .tgz dentro la cartella "/Xiaomi_MiFlash/XIAOMI-FILE/";
4- Digitare "1" per avviare FLASH FIRMWARE e alla fine delle operazioni premere un tasto qualsiasi; 
5- Selezionare il file .sh e attendere la fine delle operazioni.

informazioni files .sh:
flash_all.sh : Pulisce tutto
flash_all_except_storage.sh : Pulisce tutto tranne che la'archiviazione interna
flash_all_except_data_storage.sh : Pulisce tutto tranne i dati delle applicazioni e l'archiviazione


ENGLISH
1- Restart the device in fastboot mode;
2- Connect the device to the PC via USB cable;
3- Start the "XIAOMI TOOL" program from the terminal (cd Xiaomi_MiFlash && sudo ./go.sh) and copy the file
    of the .tgz firmware inside the "/Xiaomi_MiFlash/XIAOMI-FILE/" folder;
4- Type "1" to start FLASH FIRMWARE and at the end of the operation press any key;
5- Select the .sh file and wait for the end of the operation.

Information files .sh:
flash_all.sh : Wipes everything
flash_all_except_storage.sh : Wipes everything except internal storage
flash_all_except_data_storage.sh : wipes everything except apps data and storage


ESPAÑOLA
1- Reiniciar el dispositivo en el modo de fastboot;
2- Conectar el dispositivo al ordenador mediante un cable USB;
3- Iniciar el programa "XIAOMI TOOL" terminal (cd Xiaomi_MiFlash && sudo ./go.sh) y copiar el archivo
    .tgz el firmware dentro de la carpeta "/Xiaomi_MiFlash/XIAOMI-FILE/";
4- Tipo "1" para iniciar FIRMWARE FLASH y al final de las operaciones, pulse cualquier botón;
5- Seleccione el archivo .sh y esperar el fin de las operaciones.

archivos .sh información:
flash_all.sh : Limpia todo
flash_all_except_storage.sh : Limpia todo menos el almacenamiento interno
flash_all_except_data_storage.sh : Limpia todo menos los datos de las aplicaciones y el almacenamiento


FRANÇAIS
1- Redémarrer l'appareil en mode fastboot;
2- Connecter le périphérique à l'ordinateur via un câble USB;
3- Démarrer le programme de terminal "XIAOMI TOOL" (cd Xiaomi_MiFlash && sudo ./go.sh) et copiez le fichier
    .tgz le firmware dans le dossier "/Xiaomi_MiFlash/XIAOMI-FILE/";
4- Type "1" pour lancer FIRMWARE FLASH et à la fin des opérations, appuyer sur un bouton;
5- Sélectionnez le fichier .sh et attendre la fin des opérations.

informations fichiers .sh:
flash_all.sh : Nettoie tout
flash_all_except_storage.sh : Nettoie tout sauf le stockage interne
flash_all_except_data_storage.sh : Efface tout sauf les données et le stockage des applications

by IceMan